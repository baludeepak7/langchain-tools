import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
    plugins: [react()],
    server: {
        proxy: {
            "/api/journey": {
                target: "https://ell97oatdj.execute-api.eu-north-1.amazonaws.com",
                changeOrigin: true,
                secure: true,
                rewrite: function () { return "/uat/telco-journey-orchestrator"; },
            },
        },
    },
});
