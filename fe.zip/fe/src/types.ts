export type JourneyChannel = "TEXT" | "VOICE";

export type Emotion = "FRUSTRATED" | "NEUTRAL";

export type IntentSignal =
  | "FAMILY_DATA_INQUIRY"
  | "BILLING_INQUIRY"
  | "ROAMING_INQUIRY"
  | "GENERAL_INQUIRY";

export type UserProfile = {
  id: string;
  name: string;
  role: string;
  callerIdHashed: string;
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  text: string;
  channel: JourneyChannel;
  createdAt: number;
};

export type JourneyPayload = {
  vcb: {
    session_id: string;
    channel: JourneyChannel;
    language: "en-US";
    caller_id_hashed: string;
    cognito_token: string;
    transcript: {
      final_text: string;
      confidence: number;
    };
    audio_intelligence: {
      emotion: Emotion;
      intent_signal: IntentSignal;
    };
  };
  cognito_sub: string;
};

export type JourneyResponse = {
  responses: string[];
};

export type SpeechRecognitionResultLike = {
  readonly isFinal: boolean;
  readonly length: number;
  [index: number]: {
    readonly transcript: string;
    readonly confidence: number;
  };
};

export type SpeechRecognitionEventLike = Event & {
  readonly resultIndex: number;
  readonly results: {
    readonly length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
};

export type SpeechRecognitionErrorEventLike = Event & {
  readonly error: string;
  readonly message?: string;
};

export type BrowserSpeechRecognition = EventTarget & {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
};

export type BrowserSpeechRecognitionConstructor = new () => BrowserSpeechRecognition;

declare global {
  interface Window {
    SpeechRecognition?: BrowserSpeechRecognitionConstructor;
    webkitSpeechRecognition?: BrowserSpeechRecognitionConstructor;
  }
}
