import { useEffect, useMemo, useRef, useState } from "react";
import { RadioTower, ShieldCheck } from "lucide-react";
import { callJourneyApi, buildJourneyPayload } from "./api/journeyApi";
import { ChatWindow } from "./components/ChatWindow";
import { ErrorBanner } from "./components/ErrorBanner";
import { ModeToggle } from "./components/ModeToggle";
import { UserSelector } from "./components/UserSelector";
import type { ChatMessage, JourneyChannel, UserProfile } from "./types";
import { createSpeechRecognizer, getSpeechRecognitionSupport, speakResponses, stopSpeaking } from "./utils/voice";
import { createMessageId, createSessionId } from "./utils/session";

const SAMPLE_USERS: UserProfile[] = [
  {
    id: "demo-user-sub-001",
    name: "Deepak",
    role: "Primary Subscriber",
    callerIdHashed: "caller-hash-demo-001",
  },
  {
    id: "emma-line-001",
    name: "Emma",
    role: "Child Line",
    callerIdHashed: "caller-hash-emma-001",
  },
  {
    id: "john-line-001",
    name: "John",
    role: "Family Member",
    callerIdHashed: "caller-hash-john-001",
  },
];

function toChatMessage(role: ChatMessage["role"], text: string, channel: JourneyChannel): ChatMessage {
  return {
    id: createMessageId(),
    role,
    text,
    channel,
    createdAt: Date.now(),
  };
}

function App() {
  const [selectedUser, setSelectedUser] = useState<UserProfile>(SAMPLE_USERS[0]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [mode, setMode] = useState<JourneyChannel>("TEXT");
  const [inputValue, setInputValue] = useState("");
  const [sessionId, setSessionId] = useState(() => createSessionId());
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState("");
  const [voiceStatus, setVoiceStatus] = useState("Voice mode ready.");
  const [lastVoiceResponses, setLastVoiceResponses] = useState<string[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const recognizerRef = useRef<ReturnType<typeof createSpeechRecognizer>>(null);
  const voiceUnsupported = useMemo(() => !getSpeechRecognitionSupport(), []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, isLoading]);

  useEffect(() => {
    return () => {
      recognizerRef.current?.abort();
      stopSpeaking();
    };
  }, []);

  async function submitJourney(text: string, channel: JourneyChannel) {
    const trimmedText = text.trim();
    if (!trimmedText || isLoading) {
      return;
    }

    setError("");
    setIsLoading(true);
    setMessages((current) => [...current, toChatMessage("user", trimmedText, channel)]);

    try {
      if (channel === "VOICE") {
        setVoiceStatus("Calling Journey Lambda as VOICE...");
      }

      const payload = buildJourneyPayload(trimmedText, selectedUser, channel, sessionId);
      const result = await callJourneyApi(payload);
      const responseTexts =
        result.responses.length > 0
          ? result.responses
          : [
              "I did not receive a journey response for that turn. Please try rephrasing, or clear chat and start a fresh journey.",
            ];
      const assistantMessages = responseTexts.map((responseText) =>
        toChatMessage("assistant", responseText, channel),
      );

      setMessages((current) => [...current, ...assistantMessages]);

      if (channel === "VOICE") {
        setLastVoiceResponses(responseTexts);

        if (result.responses.length === 0) {
          const speechQueued = speakResponses(responseTexts);
          setError("Journey API returned an empty responses[] array for this turn.");
          setVoiceStatus(
            speechQueued
              ? "Lambda returned 0 responses. Speaking a fallback message."
              : "Lambda returned 0 responses. Speech synthesis is unavailable in this browser.",
          );
          return;
        }

        const speechQueued = speakResponses(responseTexts);
        setVoiceStatus(
          speechQueued
            ? `Received ${responseTexts.length} response(s). Speaking now.`
            : `Received ${responseTexts.length} response(s), but speech synthesis is unavailable in this browser.`,
        );
      }
    } catch (caughtError) {
      const message =
        caughtError instanceof Error
          ? caughtError.message
          : "Something went wrong while calling the journey API.";
      setError(message);
      if (channel === "VOICE") {
        setVoiceStatus("Voice request failed before a Lambda response was received.");
      }
    } finally {
      setIsLoading(false);
    }
  }

  function handleSendText() {
    const text = inputValue;
    setInputValue("");
    if (mode === "VOICE") {
      setVoiceStatus("Using typed transcript. Sending VOICE-channel request...");
    }
    void submitJourney(text, mode);
  }

  function handleStartVoice() {
    setError("");
    setVoiceStatus("Starting microphone...");

    const recognizer = createSpeechRecognizer({
      onListeningChange: (listening) => {
        setIsListening(listening);
        setVoiceStatus((current) => {
          if (listening) {
            return "Listening... speak now.";
          }

          return current === "Listening... speak now."
            ? "Listening stopped. Waiting for transcript..."
            : current;
        });
      },
      onTranscript: (transcript) => {
        setVoiceStatus(`Captured transcript: "${transcript.slice(0, 80)}"`);
        void submitJourney(transcript, "VOICE");
      },
      onError: (message) => {
        setError(message);
        setVoiceStatus(message);
      },
    });

    if (!recognizer) {
      const message =
        "Browser speech recognition is not supported here. Use the typed voice fallback below.";
      setError(message);
      setVoiceStatus(message);
      return;
    }

    recognizerRef.current = recognizer;

    try {
      recognizer.start();
    } catch {
      const message = "Speech recognition could not start. Check microphone permissions and try again.";
      setError(message);
      setVoiceStatus(message);
      setIsListening(false);
    }
  }

  function handleStopVoice() {
    recognizerRef.current?.stop();
    setIsListening(false);
    setVoiceStatus("Listening stopped.");
  }

  function handleReplayVoice() {
    const speechQueued = speakResponses(lastVoiceResponses);
    setVoiceStatus(
      speechQueued
        ? "Replaying the last assistant voice response."
        : "Speech synthesis is unavailable in this browser.",
    );
  }

  function handleClearChat() {
    recognizerRef.current?.abort();
    stopSpeaking();
    setMessages([]);
    setInputValue("");
    setError("");
    setSessionId(createSessionId());
    setIsListening(false);
    setVoiceStatus("Voice mode ready.");
    setLastVoiceResponses([]);
  }

  return (
    <main className="app">
      <div className="app-frame">
        <header className="hero">
          <div className="hero-topline">
            <span className="brand-mark" aria-hidden="true">
              <RadioTower size={23} />
            </span>
            <span>Journey Orchestrator POC</span>
          </div>
          <h1>Telco Journey Assistant</h1>
          <p>AI-powered family data support</p>
          <div className="hero-meta">
            <span>
              <ShieldCheck size={16} />
              Frontend-only SPA
            </span>
            <span>{sessionId}</span>
          </div>
        </header>

        {error ? <ErrorBanner message={error} onDismiss={() => setError("")} /> : null}

        <section className="control-panel" aria-label="Assistant controls">
          <UserSelector
            users={SAMPLE_USERS}
            selectedUser={selectedUser}
            onSelectUser={setSelectedUser}
          />
          <ModeToggle mode={mode} onChange={setMode} disabled={isLoading || isListening} />
        </section>

        <ChatWindow
          messages={messages}
          mode={mode}
          inputValue={inputValue}
          isLoading={isLoading}
          isListening={isListening}
          voiceUnsupported={voiceUnsupported}
          voiceStatus={voiceStatus}
          canReplayVoice={lastVoiceResponses.length > 0}
          selectedUserName={`${selectedUser.name} · ${selectedUser.role}`}
          chatEndRef={chatEndRef}
          onInputChange={setInputValue}
          onSendText={handleSendText}
          onStartVoice={handleStartVoice}
          onStopVoice={handleStopVoice}
          onReplayVoice={handleReplayVoice}
          onClearChat={handleClearChat}
        />
      </div>
    </main>
  );
}

export default App;
