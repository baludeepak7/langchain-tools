export function createSessionId(): string {
  const randomPart =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID().replace(/-/g, "").slice(0, 14).toUpperCase()
      : Math.random().toString(36).slice(2, 16).toUpperCase();

  return `SESS-${randomPart}`;
}

export function createMessageId(): string {
  const randomPart = Math.random().toString(36).slice(2, 10);
  return `msg-${Date.now()}-${randomPart}`;
}
