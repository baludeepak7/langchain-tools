import type { BrowserSpeechRecognition, SpeechRecognitionEventLike } from "../types";

export function getSpeechRecognitionSupport() {
  return window.SpeechRecognition || window.webkitSpeechRecognition;
}

function getSpeechRecognitionErrorMessage(error: string): string {
  switch (error) {
    case "not-allowed":
    case "service-not-allowed":
      return "Microphone or speech recognition permission was blocked. Allow microphone access in the browser and try again.";
    case "no-speech":
      return "No speech was detected. Try again and speak after the listening indicator appears.";
    case "audio-capture":
      return "No microphone was found or the browser could not capture audio.";
    case "network":
      return "Speech recognition could not reach the browser speech service. Check network access or use the typed voice fallback.";
    default:
      return `Speech recognition failed: ${error}`;
  }
}

export function createSpeechRecognizer(options: {
  onListeningChange: (isListening: boolean) => void;
  onTranscript: (transcript: string) => void;
  onError: (message: string) => void;
}): BrowserSpeechRecognition | null {
  const SpeechRecognition = getSpeechRecognitionSupport();

  if (!SpeechRecognition) {
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onstart = () => options.onListeningChange(true);
  recognition.onend = () => options.onListeningChange(false);
  recognition.onerror = (event) => {
    options.onListeningChange(false);
    options.onError(event.message || getSpeechRecognitionErrorMessage(event.error));
  };
  recognition.onresult = (event: SpeechRecognitionEventLike) => {
    const transcript = Array.from({ length: event.results.length })
      .map((_, index) => event.results[index]?.[0]?.transcript || "")
      .join(" ")
      .trim();

    if (transcript) {
      options.onTranscript(transcript);
    }
  };

  return recognition;
}

export function speakResponses(responses: string[]): boolean {
  if (!("speechSynthesis" in window)) {
    return false;
  }

  window.speechSynthesis.cancel();
  window.speechSynthesis.resume();

  responses.forEach((text) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    utterance.rate = 0.98;
    utterance.pitch = 1;
    utterance.volume = 1;
    window.speechSynthesis.speak(utterance);
  });

  return responses.length > 0;
}

export function stopSpeaking(): void {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
}

// TODO: Replace browser-only voice with backend audio orchestration later:
// POST microphone audio to backend, run Amazon Transcribe for STT, call Journey Lambda,
// then return Amazon Polly audio for playback. Keep AWS SDK calls out of the frontend.
