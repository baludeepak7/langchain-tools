import type {
  Emotion,
  IntentSignal,
  JourneyChannel,
  JourneyPayload,
  JourneyResponse,
  UserProfile,
} from "../types";

const LAMBDA_JOURNEY_API_URL =
  "https://ell97oatdj.execute-api.eu-north-1.amazonaws.com/uat/telco-journey-orchestrator";

const JOURNEY_API_URL = import.meta.env.DEV ? "/api/journey" : LAMBDA_JOURNEY_API_URL;
const DEV_COGNITO_TOKEN = "dev.eyJzdWIiOiJkZW1vLXVzZXIifQ.sig";
const JOURNEY_API_TIMEOUT_MS = 40_000;

function containsAny(text: string, keywords: string[]): boolean {
  const normalized = text.toLowerCase();
  return keywords.some((keyword) => normalized.includes(keyword));
}

export function inferEmotion(text: string): Emotion {
  return containsAny(text, ["again", "all", "wasted", "frustrated", "why"])
    ? "FRUSTRATED"
    : "NEUTRAL";
}

export function inferIntent(text: string): IntentSignal {
  if (containsAny(text, ["data", "gb", "used", "usage", "family", "limit", "cap"])) {
    return "FAMILY_DATA_INQUIRY";
  }

  if (containsAny(text, ["bill", "charge", "payment"])) {
    return "BILLING_INQUIRY";
  }

  if (containsAny(text, ["roaming", "abroad", "international"])) {
    return "ROAMING_INQUIRY";
  }

  return "GENERAL_INQUIRY";
}

export function buildJourneyPayload(
  text: string,
  selectedUser: UserProfile,
  channel: JourneyChannel,
  sessionId: string,
): JourneyPayload {
  return {
    vcb: {
      session_id: sessionId,
      channel,
      language: "en-US",
      caller_id_hashed: selectedUser.callerIdHashed,
      cognito_token: DEV_COGNITO_TOKEN,
      transcript: {
        final_text: text,
        confidence: 0.95,
      },
      audio_intelligence: {
        emotion: inferEmotion(text),
        intent_signal: inferIntent(text),
      },
    },
    cognito_sub: selectedUser.id,
  };
}

export async function callJourneyApi(payload: JourneyPayload): Promise<JourneyResponse> {
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), JOURNEY_API_TIMEOUT_MS);

  let response: Response;

  try {
    response = await fetch(JOURNEY_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error("Journey API timed out after 20 seconds.");
    }

    throw error;
  } finally {
    window.clearTimeout(timeoutId);
  }

  if (!response.ok) {
    const body = await response.text().catch(() => "");
    throw new Error(body || `Journey API returned ${response.status}`);
  }

  const data = (await response.json()) as Partial<JourneyResponse>;

  if (!Array.isArray(data.responses)) {
    throw new Error("Journey API response did not include responses[].");
  }

  return {
    responses: data.responses.map(String),
  };
}
