import { Bot, UserRound } from "lucide-react";
import type { ChatMessage } from "../types";

type MessageBubbleProps = {
  message: ChatMessage;
};

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";

  return (
    <article className={`message-row ${isUser ? "user" : "assistant"}`}>
      <span className="message-avatar" aria-hidden="true">
        {isUser ? <UserRound size={17} /> : <Bot size={17} />}
      </span>
      <div className="message-bubble">
        <p>{message.text}</p>
        <span>{message.channel === "VOICE" ? "Voice" : "Text"}</span>
      </div>
    </article>
  );
}
