import { FormEvent, RefObject } from "react";
import { RotateCcw, SendHorizonal, Sparkles } from "lucide-react";
import type { ChatMessage, JourneyChannel } from "../types";
import { LoadingDots } from "./LoadingDots";
import { MessageBubble } from "./MessageBubble";
import { VoiceButton } from "./VoiceButton";

type ChatWindowProps = {
  messages: ChatMessage[];
  mode: JourneyChannel;
  inputValue: string;
  isLoading: boolean;
  isListening: boolean;
  voiceUnsupported: boolean;
  voiceStatus: string;
  canReplayVoice: boolean;
  selectedUserName: string;
  chatEndRef: RefObject<HTMLDivElement>;
  onInputChange: (value: string) => void;
  onSendText: () => void;
  onStartVoice: () => void;
  onStopVoice: () => void;
  onReplayVoice: () => void;
  onClearChat: () => void;
};

export function ChatWindow({
  messages,
  mode,
  inputValue,
  isLoading,
  isListening,
  voiceUnsupported,
  voiceStatus,
  canReplayVoice,
  selectedUserName,
  chatEndRef,
  onInputChange,
  onSendText,
  onStartVoice,
  onStopVoice,
  onReplayVoice,
  onClearChat,
}: ChatWindowProps) {
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onSendText();
  }

  return (
    <section className="chat-shell" aria-label="Conversation">
      <div className="chat-toolbar">
        <div>
          <span className="eyebrow">Active line</span>
          <strong>{selectedUserName}</strong>
        </div>
        <button
          className="clear-button"
          disabled={messages.length === 0 || isLoading}
          onClick={onClearChat}
          type="button"
        >
          <RotateCcw size={17} />
          Clear
        </button>
      </div>

      <div className="message-list">
        {messages.length === 0 ? (
          <div className="empty-state">
            <span aria-hidden="true">
              <Sparkles size={30} />
            </span>
            <h2>Ask about family data, billing, roaming, or usage controls.</h2>
            <p>
              Start with something like “My daughter Emma used all our family data” and the
              assistant will route the journey request.
            </p>
          </div>
        ) : (
          messages.map((message) => <MessageBubble key={message.id} message={message} />)
        )}

        {isLoading ? (
          <article className="message-row assistant">
            <span className="message-avatar" aria-hidden="true">
              <Sparkles size={17} />
            </span>
            <div className="message-bubble loading-bubble">
              <LoadingDots />
            </div>
          </article>
        ) : null}
        <div ref={chatEndRef} />
      </div>

      <div className="input-dock">
        {mode === "TEXT" ? (
          <form className="composer" onSubmit={handleSubmit}>
            <input
              value={inputValue}
              disabled={isLoading}
              onChange={(event) => onInputChange(event.target.value)}
              placeholder="Type a journey request..."
              aria-label="Message"
            />
            <button
              disabled={isLoading || inputValue.trim().length === 0}
              type="submit"
              aria-label="Send message"
            >
              <SendHorizonal size={21} />
            </button>
          </form>
        ) : (
          <VoiceButton
            isBusy={isLoading}
            isListening={isListening}
            isUnsupported={voiceUnsupported}
            voiceStatus={voiceStatus}
            canReplayVoice={canReplayVoice}
            inputValue={inputValue}
            onInputChange={onInputChange}
            onSendFallback={onSendText}
            onStart={onStartVoice}
            onStop={onStopVoice}
            onReplayVoice={onReplayVoice}
          />
        )}
      </div>
    </section>
  );
}
