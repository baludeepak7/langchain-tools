import { CheckCircle2, UserRound } from "lucide-react";
import type { UserProfile } from "../types";

type UserSelectorProps = {
  users: UserProfile[];
  selectedUser: UserProfile;
  onSelectUser: (user: UserProfile) => void;
};

export function UserSelector({ users, selectedUser, onSelectUser }: UserSelectorProps) {
  return (
    <section className="user-selector" aria-label="Customer selector">
      {users.map((user) => {
        const isSelected = user.id === selectedUser.id;

        return (
          <button
            className={`user-card ${isSelected ? "selected" : ""}`}
            key={user.id}
            onClick={() => onSelectUser(user)}
            type="button"
            aria-pressed={isSelected}
          >
            <span className="user-avatar" aria-hidden="true">
              <UserRound size={20} />
            </span>
            <span className="user-copy">
              <span className="user-name">{user.name}</span>
              <span className="user-role">{user.role}</span>
            </span>
            {isSelected ? <CheckCircle2 className="selected-icon" size={20} /> : null}
          </button>
        );
      })}
    </section>
  );
}
