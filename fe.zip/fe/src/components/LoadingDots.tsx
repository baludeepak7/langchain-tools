export function LoadingDots() {
  return (
    <span className="loading-dots" aria-label="Assistant is typing">
      <span />
      <span />
      <span />
    </span>
  );
}
