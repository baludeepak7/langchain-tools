import { FormEvent } from "react";
import { Keyboard, Mic, SendHorizonal, Square, Volume2 } from "lucide-react";

type VoiceButtonProps = {
  isListening: boolean;
  isBusy: boolean;
  isUnsupported: boolean;
  voiceStatus: string;
  canReplayVoice: boolean;
  inputValue: string;
  onInputChange: (value: string) => void;
  onSendFallback: () => void;
  onStart: () => void;
  onStop: () => void;
  onReplayVoice: () => void;
};

export function VoiceButton({
  isListening,
  isBusy,
  isUnsupported,
  voiceStatus,
  canReplayVoice,
  inputValue,
  onInputChange,
  onSendFallback,
  onStart,
  onStop,
  onReplayVoice,
}: VoiceButtonProps) {
  function handleFallbackSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onSendFallback();
  }

  return (
    <div className="voice-panel">
      <div className="voice-status" role="status" aria-live="polite">
        {voiceStatus}
      </div>

      {!isUnsupported ? (
        <>
          <button
            className={`mic-button ${isListening ? "listening" : ""}`}
            disabled={isBusy}
            onClick={isListening ? onStop : onStart}
            type="button"
            aria-label={isListening ? "Stop listening" : "Start voice input"}
          >
            {isListening ? <Square size={28} /> : <Mic size={30} />}
          </button>
          <p>{isListening ? "Listening..." : "Tap to speak"}</p>
          <span className="voice-hint">
            <Volume2 size={15} />
            Replies play aloud after the Lambda responds.
          </span>
        </>
      ) : null}

      <div className="voice-fallback">
        <div className="voice-fallback-title">
          <Keyboard size={18} />
          {isUnsupported ? "Speech recognition unavailable" : "Typed voice fallback"}
        </div>
        <p>
          Type the transcript here to force a VOICE-channel Lambda call. Assistant replies will
          still be spoken aloud when browser speech synthesis is available.
        </p>
        <form className="voice-fallback-form" onSubmit={handleFallbackSubmit}>
          <input
            value={inputValue}
            disabled={isBusy}
            onChange={(event) => onInputChange(event.target.value)}
            placeholder="Type what you would have said..."
            aria-label="Voice fallback transcript"
          />
          <button
            disabled={isBusy || inputValue.trim().length === 0}
            type="submit"
            aria-label="Send voice fallback transcript"
          >
            <SendHorizonal size={20} />
          </button>
        </form>
      </div>

      {canReplayVoice ? (
        <button className="replay-voice-button" type="button" onClick={onReplayVoice}>
          <Volume2 size={18} />
          Replay last response
        </button>
      ) : null}
    </div>
  );
}
