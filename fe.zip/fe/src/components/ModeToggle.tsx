import { MessageSquareText, Mic2 } from "lucide-react";
import type { JourneyChannel } from "../types";

type ModeToggleProps = {
  mode: JourneyChannel;
  onChange: (mode: JourneyChannel) => void;
  disabled?: boolean;
};

export function ModeToggle({ mode, onChange, disabled = false }: ModeToggleProps) {
  return (
    <div className="mode-toggle" role="tablist" aria-label="Conversation mode">
      <button
        className={mode === "TEXT" ? "active" : ""}
        disabled={disabled}
        onClick={() => onChange("TEXT")}
        role="tab"
        type="button"
        aria-selected={mode === "TEXT"}
      >
        <MessageSquareText size={18} />
        Text
      </button>
      <button
        className={mode === "VOICE" ? "active" : ""}
        disabled={disabled}
        onClick={() => onChange("VOICE")}
        role="tab"
        type="button"
        aria-selected={mode === "VOICE"}
      >
        <Mic2 size={18} />
        Voice
      </button>
    </div>
  );
}
